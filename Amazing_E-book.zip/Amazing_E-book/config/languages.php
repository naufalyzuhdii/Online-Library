<?php
return [
    'en' => 'English',
    'id' => 'Indonesia'
];