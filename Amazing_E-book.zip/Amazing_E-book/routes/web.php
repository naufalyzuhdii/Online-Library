<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\EbookController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\MaintenanceController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'viewhome']);
Route::get('/member', [HomeController::class, 'viewhome']);
Route::get('/admin', [HomeController::class, 'viewhome']);

Route::get('/signin', [AuthController::class, 'loginPage']);
Route::post('/signin', [AuthController::class, 'login']);

Route::get('/signup', [AuthController::class, 'signupPage']);
Route::post('/signup', [AuthController::class, 'signup']);

Route::get('user', [UserController::class, 'user'])->name('user.edit');
Route::put('userupdate', [UserController::class, 'userUpdate'])->name('user.update');

Route::get('/logout', [AuthController::Class, 'logout']);

Route::group(['middleware' => ['adminsecurity']], function(){
    Route::get('/admin', [EbookController::class, 'getAll']);
    Route::get('/maintenance', [MaintenanceController::class, 'getAllUser'])->name('acc_maintenance');
    Route::get('user_detail/{id}', [MaintenanceController::class, 'detail']);
    Route::post('/role_update/{id}', [MaintenanceController::class, 'role_update'])->where("id", "[0-9]+")->name('role.update');
    Route::get('delete_user/{id}', [MaintenanceController::class, 'delete_user'])->where("id", "[0-9]+");
    Route::get('/admin-get-account', [MaintenanceController::class, 'getAllUser'])->name('getAccount');
});

Route::group(['middleware' => ['membersecurity']], function(){
    Route::get('/member', [EbookController::class, 'getAll']);
});

Route::group(['middleware' => ['authsecurity']], function(){
    Route::get('ebook_detail/{id}', [EbookController::class, 'detail']);
    Route::get('/cart/add/{id}', [OrderController::class, 'add_to_cart'])->where("id", "[0-9]+");
    Route::get('/cart/delete/{id}', [OrderController::class, 'delete_item'])->where("id", "[0-9]+");
    Route::get('/cart', [OrderController::class, 'cart']);
    Route::get('/checkout', [OrderController::class, 'checkout'])->name('checkout');
});