

<link rel="stylesheet" href="<?php echo e(asset('css/signup.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="logincontent">
    <h1>Sign Up</h1>
    <form action="/signup" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" name="first_name" placeholder="First Name">
        <input type="text" name="middle_name" placeholder="Middle Name">
        <input type="text" name="last_name" placeholder="Last Name">
        <input type="email" name="email" placeholder="Email">
        <input type="password" name="password" placeholder="Password">
        <input type="number" name="gender_id" placeholder="Gender">
        <input type="number" name="role_id" placeholder="Role">
        <input type="file" name="image">

        <input type="submit" value="Sign Up" id="loginbtn">

        <?php if($errors->any()): ?>
            <?php echo e($errors); ?>

        <?php endif; ?>
        
    </form>     
</div>
       
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/login/signup.blade.php ENDPATH**/ ?>