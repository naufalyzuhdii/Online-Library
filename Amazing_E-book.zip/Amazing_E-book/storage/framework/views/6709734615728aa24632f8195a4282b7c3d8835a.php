

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($ebook->title); ?></h1>
    <h3><?php echo e($ebook->author); ?></h3>
    <p><?php echo e($ebook->description); ?></p>
    <a href="<?php echo e(url('/cart/add/'.$ebook->id)); ?>"><button class="btn">Add to cart<span class="bg"></span></button>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/page/ebook_detail.blade.php ENDPATH**/ ?>