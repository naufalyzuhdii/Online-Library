<div>
    <h2 class="guest_content">Find and Rent Your E-Book Here!</h2>
</div><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/home/guest_home.blade.php ENDPATH**/ ?>