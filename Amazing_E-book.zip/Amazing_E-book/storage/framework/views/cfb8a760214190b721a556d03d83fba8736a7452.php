

<?php $__env->startSection('content'); ?>
    
            
            
            
    <?php if(empty($cart) || count($cart)==0): ?>
        No Data
    <?php else: ?>
    <table>
        <tr>
            <th>No.</th>
            <th>Book Title</th>
            <th>Book Author</th>
        </tr>
        <?php $no = 1;?>
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($val["title"]); ?></td>
                <td><?php echo e($val["author"]); ?></td>
                <td><a href="<?php echo e(url('/cart/delete/'.$ct)); ?>">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <form action="<?php echo e(route('checkout')); ?>" method="GET">
        <?php echo csrf_field(); ?>
        <button type="submit">CHECKOUT</button>
    </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/page/cart.blade.php ENDPATH**/ ?>