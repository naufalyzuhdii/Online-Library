<nav>
    <div class="brand">
        <h3>Amazing E-Book</h3>    
    </div>
    <div class="midnav">
        <a href="/member">Home</a>
        <a href="/cart">Cart</a>
    </div>
    <div class="profile">
        <a href="<?php echo e(route('user.edit')); ?>">Profile</a>
    </div>
</nav><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/navbar/member_navbar.blade.php ENDPATH**/ ?>