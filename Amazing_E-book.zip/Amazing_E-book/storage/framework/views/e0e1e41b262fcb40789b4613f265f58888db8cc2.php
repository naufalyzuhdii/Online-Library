

<?php $__env->startSection('content'); ?>
    <div class="profile-page">
        <h1 class="page-title">My Profile</h1>
        <img src="<?php echo e(Storage::url(Auth::user()->image)); ?>" alt="" width="200" height="200">
        <form action="<?php echo e(route('user.update')); ?>" method="post">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="profile-content">
                <input type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name', Auth::user()->first_name)); ?>" placeholder="First Name">
            </div>
            <div class="profile-content">
                <input type="text" name="middle_name" id="middle_name" value="<?php echo e(old('middle_name', Auth::user()->middle_name)); ?>" placeholder="Middke Name">
            </div>
            <div class="profile-content">
                <input type="text" name="last_name" id="last_name" value="<?php echo e(old('last_name', Auth::user()->last_name)); ?>" placeholder="Last Name">
            </div>
            <div class="profile-content">
                <input type="email" name="email" id="email" value="<?php echo e(old('email', Auth::user()->email)); ?>" placeholder="Email">
            </div>
            <div class="profile-content">
                <input type="password" name="password" id="password" value="<?php echo e(old('password', Auth::user()->password)); ?>" placeholder="Password">
            </div>
            <div class="profile-content">
                <input type="number" name="role_id" id="role_id" value="<?php echo e(old('role_id', Auth::user()->role_id)); ?>" placeholder="Role ID">
            </div>
            <div class="profile-content">
                <input type="number" name="gender_id" id="gender_id" value="<?php echo e(old('gender_id', Auth::user()->gender_id)); ?>" placeholder="Gender ID">
            </div>
            <div class="profile-content">
                <input type="file" name="image">
            </div>
            <button class="update-button">Update</button>

            <?php if($errors->any()): ?>
                <?php echo e($errors); ?>

            <?php endif; ?>
        </form>    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/page/profile.blade.php ENDPATH**/ ?>