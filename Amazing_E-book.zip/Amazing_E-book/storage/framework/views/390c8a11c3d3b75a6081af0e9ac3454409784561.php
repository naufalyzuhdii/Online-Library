Member Home
<div class="logout">
    <?php if(auth()->guard()->check()): ?>
        <form action="/logout" method="GET">
            <?php echo csrf_field(); ?>
            <input id="logout" type="submit" value="Logout">
        </form>
    <?php endif; ?>    
</div>
<?php $__currentLoopData = $ebooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="ebook_detail/<?php echo e($ebook->id); ?>"><?php echo e($ebook->title); ?></a>
    <p><?php echo e($ebook->author); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/home/member_home.blade.php ENDPATH**/ ?>