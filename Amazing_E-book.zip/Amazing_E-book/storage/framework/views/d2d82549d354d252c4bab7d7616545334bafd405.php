

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($user->first_name); ?> <?php echo e($user->middle_name); ?> <?php echo e($user->last_name); ?></h1>

    <form action="<?php echo e(route('role.update', ['id'=>$user->id])); ?>" method="post">
        <?php echo csrf_field(); ?>

        <div class="profile-content">
            <input type="number" name="role_id" id="role_id" value="<?php echo e($user->role_id); ?>" placeholder="Role ID">
        </div>

        <input type="submit" value="Update">
    </form> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/page/update_role.blade.php ENDPATH**/ ?>