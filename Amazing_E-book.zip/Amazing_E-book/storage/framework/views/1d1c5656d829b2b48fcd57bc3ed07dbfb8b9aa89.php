

<link rel="stylesheet" href="<?php echo e(asset('css/signin.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="logincontent">
    <h1>Sign In</h1>
    <form action="/signin" method="POST">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" id="email">
        <input type="password" name="password" id="password">

        
        <input type="submit" value="Sign In" id="loginbtn">
    </form>     
</div>
       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/login/signin.blade.php ENDPATH**/ ?>