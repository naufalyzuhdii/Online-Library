

<?php $__env->startSection('linkCSS'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/guest_home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/member_home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin_home.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Auth::check()): ?>
        <?php if(Auth::user()->role_id==2): ?> <?php echo $__env->make('home.member_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif(Auth::user()->role_id==1): ?> <?php echo $__env->make('home.admin_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php else: ?> <?php echo $__env->make('home.guest_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/home/auth_home.blade.php ENDPATH**/ ?>