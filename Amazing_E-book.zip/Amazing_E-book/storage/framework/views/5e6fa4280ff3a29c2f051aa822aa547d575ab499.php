

<?php $__env->startSection('content'); ?>
<table style="border-collapse: collapse">
    <thead>
        <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Role</th>
        <th>Update Role</th>
        <th>Delete</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><img src="<?php echo e(Storage::url($user->image)); ?>" alt="" width="200" height="200"></td>
                <td><?php echo e($user->first_name); ?></td>
                <td><?php echo e($user->role_id); ?></td>
                <td><a href="user_detail/<?php echo e($user->id); ?>">Update</a></td>
                <td><a href="delete_user/<?php echo e($user->id); ?>">Delete</a></td>
            </tr>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\UAS\Amazing_E-book\resources\views/page/account_maintenance.blade.php ENDPATH**/ ?>