<?php

namespace Database\Seeders;

use App\Models\Ebook;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class EbookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Ebook::create([
            'title' => 'book 1',
            'author' => 'author 1',
            'description' => 'description 1'
        ]);
        Ebook::create([
            'title' => 'book 2',
            'author' => 'author 2',
            'description' => 'description 2'
        ]);
        Ebook::create([
            'title' => 'book 3',
            'author' => 'author 3',
            'description' => 'description 3'
        ]);
    }
}
