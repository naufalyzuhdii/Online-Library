<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // User::create([
        //     'role_id' => 1,
        //     'gender_id' => 1,
        //     'first_name' => 'nama1',
        //     'middle_name' => 'nama2',
        //     'last_name' => 'nama3',
        //     'email' => 'admin@gmail.com',
        //     'password' => bcrypt('admin')
        // ]);
        // User::create([
        //     'role_id' => 2,
        //     'gender_id' => 2,
        //     'first_name' => 'nama4',
        //     'middle_name' => 'nama5',
        //     'last_name' => 'nama6',
        //     'email' => 'member@gmail.com',
        //     'password' => bcrypt('member')
        // ]);
    }
}
