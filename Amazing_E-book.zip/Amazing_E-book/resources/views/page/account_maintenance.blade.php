@extends('layout.main')

@section('content')
<table style="border-collapse: collapse">
    <thead>
        <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Role</th>
        <th>Update Role</th>
        <th>Delete</th>
    </thead>
    <tbody>
        @foreach ($users as $user)
            <tr>
                <td>{{ $user->id }}</td>
                <td><img src="{{ Storage::url($user->image) }}" alt="" width="200" height="200"></td>
                <td>{{ $user->first_name }}</td>
                <td>{{ $user->role_id }}</td>
                <td><a href="user_detail/{{ $user->id }}">Update</a></td>
                <td><a href="delete_user/{{ $user->id }}">Delete</a></td>
            </tr>    
        @endforeach
    </tbody>
</table>  
@endsection
