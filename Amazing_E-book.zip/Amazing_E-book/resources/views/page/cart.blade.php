@extends('layout.main')

@section('content')
    @if (empty($cart) || count($cart)==0)
        No Data
    @else
    <table>
        <tr>
            <th>No.</th>
            <th>Book Title</th>
            <th>Book Author</th>
        </tr>
        <?php $no = 1;?>
        @foreach ($cart as $ct => $val)
            <tr>
                <td>{{ $no++ }}</td>
                <td>{{ $val["title"] }}</td>
                <td>{{ $val["author"] }}</td>
                <td><a href="{{ url('/cart/delete/'.$ct) }}">Delete</a></td>
            </tr>
        @endforeach
    </table>
    <form action="{{ route('checkout') }}" method="GET">
        @csrf
        <button type="submit">CHECKOUT</button>
    </form>
    @endif
@endsection