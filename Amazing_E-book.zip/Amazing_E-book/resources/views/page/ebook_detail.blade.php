@extends('layout.main')

@section('content')
    <h1>{{ $ebook->title }}</h1>
    <h3>{{ $ebook->author }}</h3>
    <p>{{ $ebook->description }}</p>
    <a href="{{ url('/cart/add/'.$ebook->id) }}"><button class="btn">Add to cart<span class="bg"></span></button>    
@endsection
