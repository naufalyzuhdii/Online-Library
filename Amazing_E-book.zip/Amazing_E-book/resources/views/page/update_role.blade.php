@extends('layout.main')

@section('content')
    <h1>{{ $user->first_name }} {{ $user->middle_name }} {{ $user->last_name }}</h1>

    <form action="{{ route('role.update', ['id'=>$user->id]) }}" method="post">
        @csrf

        <div class="profile-content">
            <input type="number" name="role_id" id="role_id" value="{{ $user->role_id }}" placeholder="Role ID">
        </div>

        <input type="submit" value="Update">
    </form> 
@endsection