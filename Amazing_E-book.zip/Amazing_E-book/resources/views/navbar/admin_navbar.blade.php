<nav class="adminnav">
    <div class="brand">
        <h3>Amazing E-Book</h3>
    </div>
    <div class="midnav">
        <a href="/admin">Home</a>
        <a href="/cart">Cart</a>
        <a href="{{ route('acc_maintenance') }}">Account Maintenance</a>
    </div>
    <div class="profile">
        <a href="{{ route('user.edit') }}">Profile</a>
    </div>
</nav>