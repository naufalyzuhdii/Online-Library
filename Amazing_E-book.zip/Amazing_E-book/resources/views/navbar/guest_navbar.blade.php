<nav class="guestnav">
    <div class="brand">
        <a href="">Amazing E-Eook</a>
    </div>
    <div class="profile">
        <a href="/signin">Sign In</a>
        <a href="/signup">Sign Up</a>
    </div>
</nav>