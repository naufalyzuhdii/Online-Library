@extends('layout.main')

<link rel="stylesheet" href="{{ asset('css/signin.css') }}">

@section('content')
<div class="logincontent">
    <h1>Sign In</h1>
    <form action="/signin" method="POST">
        @csrf
        <input type="email" name="email" id="email">
        <input type="password" name="password" id="password">

        <input type="submit" value="Sign In" id="loginbtn">
    </form>     
</div>
       
@endsection
