@extends('layout.main')

<link rel="stylesheet" href="{{ asset('css/signup.css') }}">

@section('content')
<div class="logincontent">
    <h1>Sign Up</h1>
    <form action="/signup" method="POST" enctype="multipart/form-data">
        @csrf
        <input type="text" name="first_name" placeholder="First Name">
        <input type="text" name="middle_name" placeholder="Middle Name">
        <input type="text" name="last_name" placeholder="Last Name">
        <input type="email" name="email" placeholder="Email">
        <input type="password" name="password" placeholder="Password">
        <input type="number" name="gender_id" placeholder="Gender">
        <input type="number" name="role_id" placeholder="Role">
        <input type="file" name="image">

        <input type="submit" value="Sign Up" id="loginbtn">

        @if ($errors->any())
            {{ $errors }}
        @endif
        
    </form>     
</div>
       
@endsection
    