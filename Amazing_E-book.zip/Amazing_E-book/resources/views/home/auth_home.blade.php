@extends('layout.main')

@section('linkCSS')
    <link rel="stylesheet" href="{{ asset('css/guest_home.css') }}">
    <link rel="stylesheet" href="{{ asset('css/member_home.css') }}">
    <link rel="stylesheet" href="{{ asset('css/admin_home.css') }}">
@endsection

@section('content')
    @if (Auth::check())
        @if (Auth::user()->role_id==2) @include('home.member_home')
        @elseif (Auth::user()->role_id==1) @include('home.admin_home')
        @endif
    @else @include('home.guest_home')
    @endif    
@endsection