<div>
    <h2 class="guest_content">Find and Rent Your E-Book Here!</h2>
</div>