Member Home
<div class="logout">
    @auth
        <form action="/logout" method="GET">
            @csrf
            <input id="logout" type="submit" value="Logout">
        </form>
    @endauth    
</div>
@foreach ($ebooks as $ebook)
    <a href="ebook_detail/{{ $ebook->id }}">{{ $ebook->title }}</a>
    <p>{{ $ebook->author }}</p>
@endforeach