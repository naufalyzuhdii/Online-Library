<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @if (Auth::check())
        @if (Auth::user()->role=='2') <link rel="stylesheet" href="{{ asset('css/member_navbar.css') }}">
        @elseif (Auth::user()->role=='1') <link rel="stylesheet" href="{{ asset('css/admin_navbar.css') }}">
        @endif
    @else <link rel="stylesheet" href="{{ asset('css/guest_navbar.css') }}">
    @endif
    @yield('linkCSS')
    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <title>Document</title>
</head>
<body>
    @if (Auth::check())
        @if (Auth::user()->role_id=='2') @include('navbar.member_navbar')
        @elseif (Auth::user()->role_id=='1') @include('navbar.admin_navbar')
        @endif
    @else @include('navbar.guest_navbar')
    @endif
    @yield('content')
    <footer>
        <p>&copy; Amazing E-book 2022</p>
    </footer>
</body>
</html>