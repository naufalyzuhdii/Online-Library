<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasFactory;
    
    public $items;

    public function __construct($old_cart){
        if($old_cart){
            $this->items = $old_cart->items;
        }
    }
    public function add($item, $id){
        $stored_item = ['item' => $item];
        if($this->items){
            if(array_key_exists($id, $this->items)){
                $stored_item = $this->items[$id];
            }
        }
        $this->items[$id] = $stored_item;
    }
}
