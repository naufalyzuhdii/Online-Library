<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ebook extends Model
{
    use HasFactory;
    
    public function order(){
        return $this->hasMany(Order::class);
    }
    static function ebook_detail($ebook_id){
        $data = Ebook::where("id", $ebook_id)->first();
        return $data;
    }
}
