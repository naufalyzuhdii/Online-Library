<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MaintenanceController extends Controller
{
    public function getAllUser(){
        $users = User::all();

        return view('page.account_maintenance', compact('users'));
    }

    public function detail($id){
        $user = User::find($id);
        return view('page/update_role', ['user' => $user]);
    }

    public function delete_user($id){
        $user = User::find($id);
        $user->delete();

        return back();
    }

    public function role_update(Request $request, $id){
        $user = User::find($id);
        $user->update([
            'role_id' => $request->role_id,
        ]);

        return back();
    }
}
