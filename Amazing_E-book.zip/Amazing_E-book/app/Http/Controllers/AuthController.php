<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function loginPage(){
        return view('login.signin');
    }

    public function login(Request $request){
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required']
        ]);

        if(Auth::attempt($credentials, true)){
            Session::put('mysession', Auth::user()->first_name);
            if(Auth::user()->role_id == 1) return redirect('/admin');
            else if(Auth::user()->role_id == 2) return redirect('/member');
            return redirect('/guest');
        }
        return back()->withErrors("Not Registered", "signIn");
    }

    public function logout(){
        Auth::logout();
        Session::forget('mysession');
        return redirect('/signin');
    }

    public function signupPage(){
        return view('login.signup');
    }

    public function signup(Request $request){
        $rules = [
            'role_id' => 'required',
            'gender_id' => 'required',
            'first_name' => 'required',
            'middle_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|unique:users',
            'password' => 'required',
            'image' => 'required|image'
        ];
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return back()->withErrors($validator);
        }
        $user = new User();
        $user->role_id = $request->role_id;
        $user->gender_id = $request->gender_id;
        $user->first_name = $request->first_name;
        $user->middle_name = $request->middle_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->password = Hash::make($request['password']);

        $file = $request->file('image');
        $fileName = time().$file->getClientOriginalName();
        Storage::putFileAs('public/images', $file, $fileName);

        $user->image = 'images/'.$fileName;

        $user->save();
        
        return redirect('/signin');
    }
}