<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function user(){
        return view('page.profile');
    }
    public function userUpdate(Request $request){
        $request->validate([
            'role_id' => ['integer', 'required'],
            'gender_id' => ['integer', 'required'],
            'first_name' => ['string', 'required'],
            'middle_name' => ['string', 'required'],
            'last_name' => ['string', 'required'],
            'email' => ['string', 'required'],
            'password' => ['string', 'required'],
            'image' => ['string', 'required'],
        ]);
        auth()->user()->update([
            'role_id' => $request->role_id,
            'gender_id' => $request->gender_id,
            'first_name' => $request->first_name,
            'middle_name' => $request->middle_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'password' => $request->password,
            'image' => $request->image,
        ]);
        return back()->with('message', 'Your profile has been updated');
    }
}
