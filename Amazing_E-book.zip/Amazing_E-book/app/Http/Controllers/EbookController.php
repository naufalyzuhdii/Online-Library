<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Ebook;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

class EbookController extends Controller
{
    public function getAll(){
        $ebooks = Ebook::latest();
        if(request('search')){
            $ebooks->where('title', 'like', '%'. request('search'). '%');
        }
        return view('home/auth_home', [
            "ebooks" => $ebooks->paginate(9)
        ]);
    }

    public function detail($id){
        $ebook = Ebook::find($id);
        return view('page/ebook_detail', ['ebook' => $ebook]);
    }
}
