<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function viewhome(){
        return view('home.auth_home');
    }
}
