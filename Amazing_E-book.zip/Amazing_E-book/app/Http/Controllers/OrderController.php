<?php

namespace App\Http\Controllers;
// use App\Models\Cart;
use App\Models\Ebook;
use App\Models\Order;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    public function add_to_cart($ebook_id){
        $cart = session("cart");
        $ebook = Ebook::ebook_detail($ebook_id);
        $cart[$ebook_id] = [
            "title" => $ebook->title,
            "author" => $ebook->author
        ];
        session(["cart" => $cart]);

        return redirect('/cart');
    }

    public function delete_item($ebook_id){
        $cart = session("cart");
        unset($cart[$ebook_id]);
        session(["cart" => $cart]);

        return redirect('/cart');
    }

    public function cart(){
        $cart = session("cart");
        return view("page.cart")->with("cart", $cart);
    }

    public function checkout(){
        if(!Session::has('cart')){
            return redirect()->route('checkout');
            }

        Session::forget('cart');
        return back()->with('success', 'Checkout success!');
    }
}